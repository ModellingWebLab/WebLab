# Django secrets.py file for dev

SECRET_KEY = 'django very secret key, honest'

# Google OAuth2 - see http://code.google.com/apis/accounts/docs/OAuth2.html#Registering
SOCIAL_AUTH_GOOGLE_OAUTH2_KEY = ''
SOCIAL_AUTH_GOOGLE_OAUTH2_SECRET = ''

# GitHub - see https://github.com/settings/applications/new
SOCIAL_AUTH_GITHUB_KEY = ''
SOCIAL_AUTH_GITHUB_SECRET = ''

# Experiment runner backend
CHASTE_PASSWORD = 'another secret password'

# Rollbar access token
ROLLBAR_POST_SERVER_ITEM_ACCESS_TOKEN = ''
